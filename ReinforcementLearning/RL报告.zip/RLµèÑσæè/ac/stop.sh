#!/bin/bash
docker stop ac_zwz