from setuptools import setup

setup(name='myenv',
      version='0.0.1',
      install_requires=['gym===0.15.3', 'py4j==0.10.9.5', 'port-for', 'opencv-python==4.2.0.34']
)
