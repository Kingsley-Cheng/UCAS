#!/bin/bash
docker stop fighting_game